﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD
{
    public partial class frmCompras : Form
    {
        public frmCompras()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("Insert into compra (Dnicliente,Codigo) Values ('" + txtboxDni.Text + "','" + txtboxCodigo.Text + "')", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("COMPRA AGREGADA CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxCodigo.Clear();
                
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE compra set DniCliente ='" + txtboxDni + "', Codigo ='" + txtboxCodigo + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("COMPRA ACTUALIZADA CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxCodigo.Clear();
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from compra where DniCliente = '" + txtboxDni.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("COMPRA ELIMINADA CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxCodigo.Clear();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from compra order by DniCliente ASC", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                this.dgvCompras.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dgvCompras.DataSource = dt;

                txtboxDni.Clear();
                txtboxCodigo.Clear();

            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
