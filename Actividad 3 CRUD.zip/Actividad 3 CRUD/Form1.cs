﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mENSAJEDEBIENVANIDAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bienvenido a la ZAPATERIA UMI, donde encotrara la mejor calidad en calzado creado por manos mexicanas.");
        }

        private void qUIENESSOMOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("¿QUIENES SOMOS?\nSomos una empresa Mexicana, que crea productos 100% mexicanos y por manos mexicanas,lo cual es sinonimo de calidad.");
            
        }

        private void mISIÓNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MISIÓN:\nNuestra misión es darnos a conocer a nivel nacional y lograr que todos los mexicanos puedan conocer la gran calidad que puede ser creada en nuestro pais.");
        }

        private void vISIÓNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("VISIÓN:\nNuestra visión es que una vez que logremos llegar a nivel naciona, podamos ir creciendo a nivel internacional, poniendo el nombre de nuestra empresa y de nuestro pais en alto.");
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cLIENTESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClientes frmClientes = new frmClientes();
            frmClientes.Show();     
        }

        private void pROVEEDORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProveedores frmProveedores = new frmProveedores();
            frmProveedores.Show();
        }

        private void pRODUCTOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProdutos frmProdutos = new frmProdutos();
            frmProdutos.Show();
        }

        private void cOMPRASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCompras frmCompras = new frmCompras();
            frmCompras.Show();
        }

        private void dAMASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDamas frmDamas = new frmDamas();
            frmDamas.Show();
        }

        private void cABALLEROSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCaballeros frmCaballeros = new frmCaballeros();
            frmCaballeros.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
