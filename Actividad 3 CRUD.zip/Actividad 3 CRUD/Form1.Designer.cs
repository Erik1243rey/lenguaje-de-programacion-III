﻿namespace Actividad_3_CRUD
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bIENVENIDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mENSAJEDEBIENVANIDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qUIENESSOMOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mISIÓNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vISIÓNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUCTOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dAMASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cABALLEROSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGISTROToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROVEEDORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUCTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMPRASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Silver;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bIENVENIDAToolStripMenuItem,
            this.pRODUCTOSToolStripMenuItem,
            this.rEGISTROToolStripMenuItem,
            this.cOMPRASToolStripMenuItem,
            this.sALIRToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bIENVENIDAToolStripMenuItem
            // 
            this.bIENVENIDAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENSAJEDEBIENVANIDAToolStripMenuItem,
            this.qUIENESSOMOSToolStripMenuItem,
            this.mISIÓNToolStripMenuItem,
            this.vISIÓNToolStripMenuItem});
            this.bIENVENIDAToolStripMenuItem.Name = "bIENVENIDAToolStripMenuItem";
            this.bIENVENIDAToolStripMenuItem.Size = new System.Drawing.Size(109, 24);
            this.bIENVENIDAToolStripMenuItem.Text = "BIENVENIDA";
            // 
            // mENSAJEDEBIENVANIDAToolStripMenuItem
            // 
            this.mENSAJEDEBIENVANIDAToolStripMenuItem.Name = "mENSAJEDEBIENVANIDAToolStripMenuItem";
            this.mENSAJEDEBIENVANIDAToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.mENSAJEDEBIENVANIDAToolStripMenuItem.Text = "MENSAJE DE BIENVANIDA";
            this.mENSAJEDEBIENVANIDAToolStripMenuItem.Click += new System.EventHandler(this.mENSAJEDEBIENVANIDAToolStripMenuItem_Click);
            // 
            // qUIENESSOMOSToolStripMenuItem
            // 
            this.qUIENESSOMOSToolStripMenuItem.Name = "qUIENESSOMOSToolStripMenuItem";
            this.qUIENESSOMOSToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.qUIENESSOMOSToolStripMenuItem.Text = "¿QUIENES SOMOS?";
            this.qUIENESSOMOSToolStripMenuItem.Click += new System.EventHandler(this.qUIENESSOMOSToolStripMenuItem_Click);
            // 
            // mISIÓNToolStripMenuItem
            // 
            this.mISIÓNToolStripMenuItem.Name = "mISIÓNToolStripMenuItem";
            this.mISIÓNToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.mISIÓNToolStripMenuItem.Text = "MISIÓN";
            this.mISIÓNToolStripMenuItem.Click += new System.EventHandler(this.mISIÓNToolStripMenuItem_Click);
            // 
            // vISIÓNToolStripMenuItem
            // 
            this.vISIÓNToolStripMenuItem.Name = "vISIÓNToolStripMenuItem";
            this.vISIÓNToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.vISIÓNToolStripMenuItem.Text = "VISIÓN";
            this.vISIÓNToolStripMenuItem.Click += new System.EventHandler(this.vISIÓNToolStripMenuItem_Click);
            // 
            // pRODUCTOSToolStripMenuItem
            // 
            this.pRODUCTOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dAMASToolStripMenuItem,
            this.cABALLEROSToolStripMenuItem});
            this.pRODUCTOSToolStripMenuItem.Name = "pRODUCTOSToolStripMenuItem";
            this.pRODUCTOSToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
            this.pRODUCTOSToolStripMenuItem.Text = "PRODUCTOS";
            // 
            // dAMASToolStripMenuItem
            // 
            this.dAMASToolStripMenuItem.Name = "dAMASToolStripMenuItem";
            this.dAMASToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.dAMASToolStripMenuItem.Text = "DAMAS";
            this.dAMASToolStripMenuItem.Click += new System.EventHandler(this.dAMASToolStripMenuItem_Click);
            // 
            // cABALLEROSToolStripMenuItem
            // 
            this.cABALLEROSToolStripMenuItem.Name = "cABALLEROSToolStripMenuItem";
            this.cABALLEROSToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.cABALLEROSToolStripMenuItem.Text = "CABALLEROS";
            this.cABALLEROSToolStripMenuItem.Click += new System.EventHandler(this.cABALLEROSToolStripMenuItem_Click);
            // 
            // rEGISTROToolStripMenuItem
            // 
            this.rEGISTROToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLIENTESToolStripMenuItem,
            this.pROVEEDORToolStripMenuItem,
            this.pRODUCTOToolStripMenuItem});
            this.rEGISTROToolStripMenuItem.Name = "rEGISTROToolStripMenuItem";
            this.rEGISTROToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.rEGISTROToolStripMenuItem.Text = "REGISTRO";
            // 
            // cLIENTESToolStripMenuItem
            // 
            this.cLIENTESToolStripMenuItem.Name = "cLIENTESToolStripMenuItem";
            this.cLIENTESToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.cLIENTESToolStripMenuItem.Text = "CLIENTES";
            this.cLIENTESToolStripMenuItem.Click += new System.EventHandler(this.cLIENTESToolStripMenuItem_Click);
            // 
            // pROVEEDORToolStripMenuItem
            // 
            this.pROVEEDORToolStripMenuItem.Name = "pROVEEDORToolStripMenuItem";
            this.pROVEEDORToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.pROVEEDORToolStripMenuItem.Text = "PROVEEDOR";
            this.pROVEEDORToolStripMenuItem.Click += new System.EventHandler(this.pROVEEDORToolStripMenuItem_Click);
            // 
            // pRODUCTOToolStripMenuItem
            // 
            this.pRODUCTOToolStripMenuItem.Name = "pRODUCTOToolStripMenuItem";
            this.pRODUCTOToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.pRODUCTOToolStripMenuItem.Text = "PRODUCTOS";
            this.pRODUCTOToolStripMenuItem.Click += new System.EventHandler(this.pRODUCTOToolStripMenuItem_Click);
            // 
            // cOMPRASToolStripMenuItem
            // 
            this.cOMPRASToolStripMenuItem.Name = "cOMPRASToolStripMenuItem";
            this.cOMPRASToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.cOMPRASToolStripMenuItem.Text = "COMPRAS";
            this.cOMPRASToolStripMenuItem.Click += new System.EventHandler(this.cOMPRASToolStripMenuItem_Click);
            // 
            // sALIRToolStripMenuItem
            // 
            this.sALIRToolStripMenuItem.Name = "sALIRToolStripMenuItem";
            this.sALIRToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.sALIRToolStripMenuItem.Text = "SALIR";
            this.sALIRToolStripMenuItem.Click += new System.EventHandler(this.sALIRToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 407);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "ZAPATERIA UMI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bIENVENIDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mENSAJEDEBIENVANIDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dAMASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cABALLEROSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEGISTROToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLIENTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROVEEDORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cOMPRASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qUIENESSOMOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mISIÓNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vISIÓNToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

