﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD
{
    public partial class frmProdutos : Form
    {
        public frmProdutos()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("Insert into Producto (Codigo,Nombre,Precio,DniProveedor) Values ('" + textboxCodigo.Text + "','" + txtboxNombre.Text + "','" + txtboxPrecio.Text + "','" +txtboxProveedor.Text+"')", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PRODUCTO AGREGADO CORRECTAMENTE");
                textboxCodigo.Clear();
                txtboxNombre.Clear();
                txtboxPrecio.Clear();
                txtboxProveedor.Clear();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Producto set Nombre ='" + txtboxNombre.Text + "', precio ='" + txtboxPrecio.Text + "',DniProveedor ='"+txtboxProveedor.Text+"'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PRODUCTO ACTUALIZADO CORRECTAMENTE");
                textboxCodigo.Clear();
                txtboxNombre.Clear();
                txtboxPrecio.Clear();
                txtboxProveedor.Clear();
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from Producto where Codigo = '" + textboxCodigo.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PRODUCTO ELIMINADO CORRECTAMENTE");
                textboxCodigo.Clear();
                txtboxNombre.Clear();
                txtboxPrecio.Clear();
                txtboxProveedor.Clear();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Producto order by Nombre ASC", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                this.dgvProducto.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dgvProducto.DataSource = dt;

                textboxCodigo.Clear();
                txtboxNombre.Clear();
                txtboxPrecio.Clear();
                txtboxProveedor.Clear();

            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
