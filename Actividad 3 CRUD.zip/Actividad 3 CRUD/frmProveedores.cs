﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD
{
    public partial class frmProveedores : Form
    {
        public frmProveedores()
        {
            InitializeComponent();
        }

        private void frmProveedores_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("Insert into Proveedor (DniProveedor,Nombre,Direccion) Values ('" + txtboxDni.Text + "','" + txtboxNombre.Text + "','" + txtboxDireccion.Text + "')", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PROVEEDOR AGREGADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxDireccion.Clear();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Proveedor set Nombre ='" + txtboxNombre.Text + "', Direccion ='" + txtboxDireccion.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PROVEEDOR ACTUALIZADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxDireccion.Clear();
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from Proveedor where DniProveedor = '" + txtboxDni.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("PROVEEDOR ELIMINADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxDireccion.Clear();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Proveedor order by Nombre ASC", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                this.dgvProveedore.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dgvProveedore.DataSource = dt;

                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxDireccion.Clear();

            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
