﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD
{
    public partial class frmClientes : Form
    {
        public frmClientes()
        {
            InitializeComponent();
        }

        private void frmClientes_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("Insert into Cliente (DniCliente,Nombres,Apellidos,FechaNac,Telefono) Values ('" + txtboxDni.Text + "','" + txtboxNombre.Text + "','" + txtboxApellido.Text + "','" + txtboxFecha.Text + "','" + txtboxTelefono.Text + "')", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("CONTACTO AGREGADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxApellido.Clear();
                txtboxFecha.Clear();
                txtboxTelefono.Clear();
            }

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Cliente set Nombres ='" + txtboxNombre.Text + "', Apellidos ='" + txtboxApellido.Text + "',FechaNac = '" + txtboxFecha.Text + "',Telefono = '" + txtboxTelefono.Text + "' where DniCliente = '" + txtboxDni.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("CONTACTO ACTUALIZADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxApellido.Clear();
                txtboxFecha.Clear();
                txtboxTelefono.Clear();
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from Cliente where DniCliente = '" + txtboxDni.Text + "'", cn);
                cmd.CommandType = CommandType.Text;
                cn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("CONTACTO ELIMINADO CORRECTAMENTE");
                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxApellido.Clear();
                txtboxFecha.Clear();
                txtboxTelefono.Clear();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=Zapateria_UMI1;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Cliente order by Nombres ASC", cn);
                da.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                da.Fill(dt);
                this.dgvCliente.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dgvCliente.DataSource = dt;

                txtboxDni.Clear();
                txtboxNombre.Clear();
                txtboxApellido.Clear();
                txtboxFecha.Clear();
                txtboxTelefono.Clear();

            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
