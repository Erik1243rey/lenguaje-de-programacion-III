create database Zapateria_UMI1

create table Cliente(
DniCliente varchar (10) primary key not null ,
Nombres varchar (50) not null,
Apellidos varchar (50)not null,
FechaNac varchar (15)not null,
Telefono varchar (10)not null,
);


create table Proveedor (
DniProveedor varchar (10) primary key not null,
Nombre varchar (50) not null,
Direccion varchar (60)not null,
);

Create table Producto (
Codigo varchar (10) primary key not null,
Nombre varchar (50) not null,
Precio Varchar (40) not null,
DniProveedor varchar (10) not null,
foreign key (DniProveedor) references Proveedor (DniProveedor)
);

create table compra (
DniCliente varchar (10) not null,
Codigo varchar (10) not null,
foreign key (DniCliente) references cliente (DniCliente),
foreign key (Codigo) references Producto (Codigo)
);

select * from Cliente
SELECT * FROM Producto

drop table compra
drop table Producto
drop table Proveedor
drop table Cliente