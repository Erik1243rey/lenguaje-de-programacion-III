﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class frmIngreso : Form
    {
        public frmIngreso()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if(txtboxContrasena.Text == "")
            {
                MessageBox.Show("INGRESAR CONTRASEÑA");
            }else if(txtboxContrasena.Text == "12345")
            {
                Form formulario = new Form1();
                formulario.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("CONTRASEÑA INCORRECTA");
                txtboxContrasena.Clear();
            }
        }
    }
}
