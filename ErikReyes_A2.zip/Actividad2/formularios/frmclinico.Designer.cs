﻿namespace Actividad2.formularios
{
    partial class frmclinico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmclinico));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbboxEnfermedad = new System.Windows.Forms.ComboBox();
            this.rdbNo = new System.Windows.Forms.RadioButton();
            this.rdbSi = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmboxAlergias = new System.Windows.Forms.ComboBox();
            this.rdbNo2 = new System.Windows.Forms.RadioButton();
            this.rdbSi2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmboxOperacion = new System.Windows.Forms.ComboBox();
            this.rdbNo3 = new System.Windows.Forms.RadioButton();
            this.rdbSi3 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmboxEjercicio = new System.Windows.Forms.ComboBox();
            this.rdbNo4 = new System.Windows.Forms.RadioButton();
            this.rdbSi4 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdbNo5 = new System.Windows.Forms.RadioButton();
            this.rdbSi5 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbboxEnfermedad);
            this.groupBox1.Controls.Add(this.rdbNo);
            this.groupBox1.Controls.Add(this.rdbSi);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(24, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(356, 81);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // cmbboxEnfermedad
            // 
            this.cmbboxEnfermedad.FormattingEnabled = true;
            this.cmbboxEnfermedad.Items.AddRange(new object[] {
            "HIPERTENSIÓN",
            "DIABETES",
            "ENFERMEDADES DEL CORAZÓN",
            "ASMA",
            "COLESTEROL ALTO",
            "DEFECTOS CONGENITOS",
            "PERDIDA AUDITIVA"});
            this.cmbboxEnfermedad.Location = new System.Drawing.Point(119, 41);
            this.cmbboxEnfermedad.Name = "cmbboxEnfermedad";
            this.cmbboxEnfermedad.Size = new System.Drawing.Size(215, 21);
            this.cmbboxEnfermedad.TabIndex = 3;
            this.cmbboxEnfermedad.Text = "-- Selecciona --";
            // 
            // rdbNo
            // 
            this.rdbNo.AutoSize = true;
            this.rdbNo.Location = new System.Drawing.Point(15, 55);
            this.rdbNo.Name = "rdbNo";
            this.rdbNo.Size = new System.Drawing.Size(41, 17);
            this.rdbNo.TabIndex = 2;
            this.rdbNo.TabStop = true;
            this.rdbNo.Text = "NO";
            this.rdbNo.UseVisualStyleBackColor = true;
            // 
            // rdbSi
            // 
            this.rdbSi.AutoSize = true;
            this.rdbSi.Location = new System.Drawing.Point(15, 32);
            this.rdbSi.Name = "rdbSi";
            this.rdbSi.Size = new System.Drawing.Size(35, 17);
            this.rdbSi.TabIndex = 1;
            this.rdbSi.TabStop = true;
            this.rdbSi.Text = "SI";
            this.rdbSi.UseVisualStyleBackColor = true;
            this.rdbSi.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "¿PADECES ALGUNA ENFERMEDAD?";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmboxAlergias);
            this.groupBox2.Controls.Add(this.rdbNo2);
            this.groupBox2.Controls.Add(this.rdbSi2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(24, 113);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(356, 80);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // cmboxAlergias
            // 
            this.cmboxAlergias.FormattingEnabled = true;
            this.cmboxAlergias.Items.AddRange(new object[] {
            "ALERGIAS A MEDICAMENTOS",
            "ALERGIAS A ALIMENTOS",
            "ALERGIA AL POLEN",
            "ALERGIA A LOS COSMETICOS",
            "ALERGIA A LOS ACAROS DEL POLVO"});
            this.cmboxAlergias.Location = new System.Drawing.Point(119, 41);
            this.cmboxAlergias.Name = "cmboxAlergias";
            this.cmboxAlergias.Size = new System.Drawing.Size(215, 21);
            this.cmboxAlergias.TabIndex = 7;
            this.cmboxAlergias.Text = "-- Selecciona --";
            // 
            // rdbNo2
            // 
            this.rdbNo2.AutoSize = true;
            this.rdbNo2.Location = new System.Drawing.Point(15, 55);
            this.rdbNo2.Name = "rdbNo2";
            this.rdbNo2.Size = new System.Drawing.Size(41, 17);
            this.rdbNo2.TabIndex = 6;
            this.rdbNo2.TabStop = true;
            this.rdbNo2.Text = "NO";
            this.rdbNo2.UseVisualStyleBackColor = true;
            // 
            // rdbSi2
            // 
            this.rdbSi2.AutoSize = true;
            this.rdbSi2.Location = new System.Drawing.Point(15, 32);
            this.rdbSi2.Name = "rdbSi2";
            this.rdbSi2.Size = new System.Drawing.Size(35, 17);
            this.rdbSi2.TabIndex = 5;
            this.rdbSi2.TabStop = true;
            this.rdbSi2.Text = "SI";
            this.rdbSi2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "¿TIENES ALERGIAS?";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmboxOperacion);
            this.groupBox3.Controls.Add(this.rdbNo3);
            this.groupBox3.Controls.Add(this.rdbSi3);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(24, 199);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(356, 84);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // cmboxOperacion
            // 
            this.cmboxOperacion.FormattingEnabled = true;
            this.cmboxOperacion.Items.AddRange(new object[] {
            "LAPAROTOMÍA",
            "HERNIORRAFÍA UMBILICAL",
            "APENDICETOMÍA",
            "DERIVACIÓN VENTRICULAR",
            "ESTRIPACIÓN DE TEJIDO DE PIEL",
            "RECONSTRUCCIÓN DEL SISTEMA OSEO"});
            this.cmboxOperacion.Location = new System.Drawing.Point(119, 41);
            this.cmboxOperacion.Name = "cmboxOperacion";
            this.cmboxOperacion.Size = new System.Drawing.Size(215, 21);
            this.cmboxOperacion.TabIndex = 7;
            this.cmboxOperacion.Text = "-- Selecciona --";
            // 
            // rdbNo3
            // 
            this.rdbNo3.AutoSize = true;
            this.rdbNo3.Location = new System.Drawing.Point(15, 55);
            this.rdbNo3.Name = "rdbNo3";
            this.rdbNo3.Size = new System.Drawing.Size(41, 17);
            this.rdbNo3.TabIndex = 6;
            this.rdbNo3.TabStop = true;
            this.rdbNo3.Text = "NO";
            this.rdbNo3.UseVisualStyleBackColor = true;
            // 
            // rdbSi3
            // 
            this.rdbSi3.AutoSize = true;
            this.rdbSi3.Location = new System.Drawing.Point(15, 32);
            this.rdbSi3.Name = "rdbSi3";
            this.rdbSi3.Size = new System.Drawing.Size(35, 17);
            this.rdbSi3.TabIndex = 5;
            this.rdbSi3.TabStop = true;
            this.rdbSi3.Text = "SI";
            this.rdbSi3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "¿ALGUNA VEZ TE HAN OPERADO?";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cmboxEjercicio);
            this.groupBox4.Controls.Add(this.rdbNo4);
            this.groupBox4.Controls.Add(this.rdbSi4);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(24, 289);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(356, 81);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // cmboxEjercicio
            // 
            this.cmboxEjercicio.FormattingEnabled = true;
            this.cmboxEjercicio.Items.AddRange(new object[] {
            "RESISTENCIA",
            "FORTALECIMIENTO",
            "EQUILIBRIO",
            "FLEXIBILIDAD",
            "POTENCIA",
            "CARDIOVASCULAR"});
            this.cmboxEjercicio.Location = new System.Drawing.Point(119, 41);
            this.cmboxEjercicio.Name = "cmboxEjercicio";
            this.cmboxEjercicio.Size = new System.Drawing.Size(215, 21);
            this.cmboxEjercicio.TabIndex = 7;
            this.cmboxEjercicio.Text = "-- Selecciona --";
            // 
            // rdbNo4
            // 
            this.rdbNo4.AutoSize = true;
            this.rdbNo4.Location = new System.Drawing.Point(15, 55);
            this.rdbNo4.Name = "rdbNo4";
            this.rdbNo4.Size = new System.Drawing.Size(41, 17);
            this.rdbNo4.TabIndex = 6;
            this.rdbNo4.TabStop = true;
            this.rdbNo4.Text = "NO";
            this.rdbNo4.UseVisualStyleBackColor = true;
            // 
            // rdbSi4
            // 
            this.rdbSi4.AutoSize = true;
            this.rdbSi4.Location = new System.Drawing.Point(15, 32);
            this.rdbSi4.Name = "rdbSi4";
            this.rdbSi4.Size = new System.Drawing.Size(35, 17);
            this.rdbSi4.TabIndex = 5;
            this.rdbSi4.TabStop = true;
            this.rdbSi4.Text = "SI";
            this.rdbSi4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "¿HACER EJERCICIO?";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdbNo5);
            this.groupBox5.Controls.Add(this.rdbSi5);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Location = new System.Drawing.Point(24, 376);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(356, 82);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            // 
            // rdbNo5
            // 
            this.rdbNo5.AutoSize = true;
            this.rdbNo5.Location = new System.Drawing.Point(15, 55);
            this.rdbNo5.Name = "rdbNo5";
            this.rdbNo5.Size = new System.Drawing.Size(41, 17);
            this.rdbNo5.TabIndex = 6;
            this.rdbNo5.TabStop = true;
            this.rdbNo5.Text = "NO";
            this.rdbNo5.UseVisualStyleBackColor = true;
            // 
            // rdbSi5
            // 
            this.rdbSi5.AutoSize = true;
            this.rdbSi5.Location = new System.Drawing.Point(15, 32);
            this.rdbSi5.Name = "rdbSi5";
            this.rdbSi5.Size = new System.Drawing.Size(35, 17);
            this.rdbSi5.TabIndex = 5;
            this.rdbSi5.TabStop = true;
            this.rdbSi5.Text = "SI";
            this.rdbSi5.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "¿PADECES DEPRESIÓN?";
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGuardar.Location = new System.Drawing.Point(386, 357);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(282, 36);
            this.btnGuardar.TabIndex = 4;
            this.btnGuardar.Text = "GUARDAR";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnRegresar.Location = new System.Drawing.Point(386, 412);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(282, 36);
            this.btnRegresar.TabIndex = 5;
            this.btnRegresar.Text = "REGRESAR";
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(386, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(282, 304);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // frmclinico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(688, 472);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmclinico";
            this.Text = "Datos Clinicos";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbboxEnfermedad;
        private System.Windows.Forms.RadioButton rdbNo;
        private System.Windows.Forms.RadioButton rdbSi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox cmboxAlergias;
        private System.Windows.Forms.RadioButton rdbNo2;
        private System.Windows.Forms.RadioButton rdbSi2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmboxOperacion;
        private System.Windows.Forms.RadioButton rdbNo3;
        private System.Windows.Forms.RadioButton rdbSi3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmboxEjercicio;
        private System.Windows.Forms.RadioButton rdbNo4;
        private System.Windows.Forms.RadioButton rdbSi4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdbNo5;
        private System.Windows.Forms.RadioButton rdbSi5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnRegresar;
    }
}