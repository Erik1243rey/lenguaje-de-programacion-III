﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2.formularios
{
    public partial class FrmSaludo : Form
    {
        public FrmSaludo()
        {
            InitializeComponent();
        }

        private void btnSaludo_Click(object sender, EventArgs e)
        {
            clases.clsSaludo aviso = new clases.clsSaludo();
            string Saludo1 = aviso.Saludar(txtboxNombre.Text);
            MessageBox.Show(Saludo1);
        }

        private void FrmSaludo_Load(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form formulario = new Form1();
            formulario.Show();

            this.Hide();
        }
    }
}
