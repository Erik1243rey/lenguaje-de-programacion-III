﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2.formularios
{
    public partial class frmDatosPer : Form
    {
        public frmDatosPer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

                clases.clsDatos clsDatos = new clases.clsDatos();
            string guardar = clsDatos.guardar(txtboxNombre.Text, txtboxApellido.Text, txtboxDireccion.Text, txtboxCiudad.Text, dtpFecha.Text, cmboxCivil.Text, lblSexo.Text);
            MessageBox.Show(guardar);

            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form formulario = new Form1();
            formulario.Show();

            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
        if (rdbMasculino.Checked)
        {
            this.lblSexo.Text = "MASCULINO";
        }
            if (rdbFemenino.Checked)
            {
                this.lblSexo.Text = "FEMENINO";
            }


        }
    }
}
