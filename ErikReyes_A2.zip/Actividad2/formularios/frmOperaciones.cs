﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2.formularios
{
    public partial class frmOperaciones : Form
    {
        public frmOperaciones()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int resultado;
            clases.clsOperaciones clsOperaciones = new clases.clsOperaciones();
            resultado = clsOperaciones.sumar(int.Parse(txtboxNumero1.Text), int.Parse(txtboxNumero2.Text),int.Parse(txtboxNumero3.Text),int.Parse(txtboxNumero4.Text),int.Parse(txtboxNumero5.Text),int.Parse(txtboxNumero6.Text));
            txtboxResultado.Text = resultado.ToString();
        }

        private void btnRestar_Click(object sender, EventArgs e)
        {
            int resultado2;
            clases.clsOperaciones clsOperaciones = new clases.clsOperaciones();
            resultado2 = clsOperaciones.restar(int.Parse(txtboxNumero1.Text), int.Parse(txtboxNumero2.Text), int.Parse(txtboxNumero3.Text), int.Parse(txtboxNumero4.Text), int.Parse(txtboxNumero5.Text), int.Parse(txtboxNumero6.Text));
            txtboxResultado.Text = resultado2.ToString();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            int resultado3;
            clases.clsOperaciones clsOperaciones = new clases.clsOperaciones();
            resultado3 = clsOperaciones.multiplicar(int.Parse(txtboxNumero1.Text), int.Parse(txtboxNumero2.Text), int.Parse(txtboxNumero3.Text), int.Parse(txtboxNumero4.Text), int.Parse(txtboxNumero5.Text), int.Parse(txtboxNumero6.Text));
            txtboxResultado.Text = resultado3.ToString();
        }

        private void btnDivision_Click(object sender, EventArgs e)
        {
            double resultado4;
            clases.clsOperaciones clsOperaciones = new clases.clsOperaciones();
            resultado4 = clsOperaciones.dividir(double.Parse(txtboxNumero1.Text), double.Parse(txtboxNumero2.Text), double.Parse(txtboxNumero3.Text), double.Parse(txtboxNumero4.Text), double.Parse(txtboxNumero5.Text), double.Parse(txtboxNumero6.Text));
            txtboxResultado.Text = resultado4.ToString();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form formulario = new Form1();
            formulario.Show();

            this.Hide();
        }
        private void limpiarctrs()
        {
           
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtboxNumero1.Text = String.Empty;
            txtboxNumero2.Text = String.Empty;
            txtboxNumero3.Text = String.Empty;
            txtboxNumero4.Text = String.Empty;
            txtboxNumero5.Text = String.Empty;
            txtboxNumero6.Text = String.Empty;
            txtboxResultado.Text = String.Empty;
        }
    }
}
