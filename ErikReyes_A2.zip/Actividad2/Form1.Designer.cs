﻿namespace Actividad2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.saludoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.datosPersonalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.datosPersonalesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.datosClinicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionesBásicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saludoToolStripMenuItem,
            this.datosPersonalesToolStripMenuItem,
            this.operacionesBásicasToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(457, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // saludoToolStripMenuItem
            // 
            this.saludoToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.saludoToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saludoToolStripMenuItem.Name = "saludoToolStripMenuItem";
            this.saludoToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.saludoToolStripMenuItem.Text = "Saludo";
            this.saludoToolStripMenuItem.Click += new System.EventHandler(this.saludoToolStripMenuItem_Click);
            // 
            // datosPersonalesToolStripMenuItem
            // 
            this.datosPersonalesToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.datosPersonalesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datosPersonalesToolStripMenuItem1,
            this.datosClinicosToolStripMenuItem});
            this.datosPersonalesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datosPersonalesToolStripMenuItem.Name = "datosPersonalesToolStripMenuItem";
            this.datosPersonalesToolStripMenuItem.Size = new System.Drawing.Size(160, 24);
            this.datosPersonalesToolStripMenuItem.Text = "Información Personal";
            // 
            // datosPersonalesToolStripMenuItem1
            // 
            this.datosPersonalesToolStripMenuItem1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.datosPersonalesToolStripMenuItem1.Name = "datosPersonalesToolStripMenuItem1";
            this.datosPersonalesToolStripMenuItem1.Size = new System.Drawing.Size(192, 24);
            this.datosPersonalesToolStripMenuItem1.Text = "Datos personales";
            this.datosPersonalesToolStripMenuItem1.Click += new System.EventHandler(this.datosPersonalesToolStripMenuItem1_Click);
            // 
            // datosClinicosToolStripMenuItem
            // 
            this.datosClinicosToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.datosClinicosToolStripMenuItem.Name = "datosClinicosToolStripMenuItem";
            this.datosClinicosToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.datosClinicosToolStripMenuItem.Text = "Datos Clinicos";
            this.datosClinicosToolStripMenuItem.Click += new System.EventHandler(this.datosClinicosToolStripMenuItem_Click);
            // 
            // operacionesBásicasToolStripMenuItem
            // 
            this.operacionesBásicasToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.operacionesBásicasToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.operacionesBásicasToolStripMenuItem.Name = "operacionesBásicasToolStripMenuItem";
            this.operacionesBásicasToolStripMenuItem.Size = new System.Drawing.Size(156, 24);
            this.operacionesBásicasToolStripMenuItem.Text = "Operaciones Básicas";
            this.operacionesBásicasToolStripMenuItem.Click += new System.EventHandler(this.operacionesBásicasToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.salirToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(50, 24);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Actividad2.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(94, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(274, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(457, 307);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "MENU";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem saludoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem datosPersonalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionesBásicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem datosPersonalesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem datosClinicosToolStripMenuItem;
    }
}

