﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2.clases
{
    public class clsClinico
    {
        public string Clinico()

        {
        string clinico;
        clinico = "DATOS CORRECTAMENTE GUARDADOS";
            return clinico;
        }
    }
}
