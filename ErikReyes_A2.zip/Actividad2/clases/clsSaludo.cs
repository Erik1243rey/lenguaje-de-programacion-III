﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2.clases
{
    public class clsSaludo
    {
        public string Saludar (string nombre)
        {
            string Saludo;
            Saludo = "HOLA " + nombre + ", ¿QUÉ TAL VA TU DÍA?";
            return Saludo;
        }

    }
}
