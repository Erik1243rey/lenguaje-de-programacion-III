﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2.clases
{
    public class clsDatos
    {
        public string guardar(string nombre, string apellido, string direccion,string ciudad, string fechaNac, string civil, string sexo)
        {
            string guardare;
            guardare = "DATOS GUARDADOS DE:" + nombre +", "+ apellido +", "+ direccion +" ,"+ ciudad +", "+ fechaNac +" ,"+ civil +", "+ sexo;
            return guardare;
        }
    }
}
