﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void saludoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formularios.FrmSaludo frmSaludo = new formularios.FrmSaludo();
            frmSaludo.Show();

            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void datosPersonalesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            formularios.frmDatosPer frmDatosPer = new formularios.frmDatosPer();
            frmDatosPer.Show();

            this.Hide();
            
        }

        private void datosClinicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formularios.frmclinico frmclinico = new formularios.frmclinico();
            frmclinico.Show();

            this.Hide();
        }

        private void operacionesBásicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formularios.frmOperaciones frmOperaciones = new formularios.frmOperaciones();
            frmOperaciones.Show();

            this.Hide();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
