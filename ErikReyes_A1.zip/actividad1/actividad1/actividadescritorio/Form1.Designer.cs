﻿namespace actividadescritorio
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmboxEdos = new System.Windows.Forms.ComboBox();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.txtfecha = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.grpboxHorarios = new System.Windows.Forms.GroupBox();
            this.btnHorario = new System.Windows.Forms.Button();
            this.lblHorario = new System.Windows.Forms.Label();
            this.rdbmatutino = new System.Windows.Forms.RadioButton();
            this.rdbvespertino = new System.Windows.Forms.RadioButton();
            this.btnagregar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.grpboxHorarios.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cmboxEdos);
            this.groupBox1.Controls.Add(this.txtdireccion);
            this.groupBox1.Controls.Add(this.txtfecha);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtnombre);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(21, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(311, 234);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "SELECCIONA TU ESTADO";
            // 
            // cmboxEdos
            // 
            this.cmboxEdos.ForeColor = System.Drawing.SystemColors.MenuText;
            this.cmboxEdos.FormattingEnabled = true;
            this.cmboxEdos.Items.AddRange(new object[] {
            "AGUASCALIENTES",
            "BAJA CALIFORNIA",
            "BAJA CALIFORNIA SUR",
            "CAMPECHE",
            "CHIAPAS",
            "CHIHUAHUA",
            "COAHUILA",
            "COLIMA",
            "CIUDAD DE MEXICO",
            "DURANGO",
            "ESTADO DE MEXICO",
            "GUANAJUATO",
            "GUERRERO",
            "HIDALGO",
            "JALISCO",
            "MICHOACAN",
            "MORELOS",
            "NAYARIT",
            "NUEVO LEON",
            "OAXACA",
            "PUEBLA",
            "QUERETARO",
            "QUINTANA ROO",
            "SAL LUIS POTOSI",
            "SINALOA",
            "SONORA",
            "TABASCO",
            "TAMAULIPAS",
            "TLAXCALA",
            "VERACRUZ",
            "YUCATAN"});
            this.cmboxEdos.Location = new System.Drawing.Point(9, 185);
            this.cmboxEdos.Name = "cmboxEdos";
            this.cmboxEdos.Size = new System.Drawing.Size(121, 21);
            this.cmboxEdos.TabIndex = 3;
            this.cmboxEdos.Text = "-- Selecciona --";
            // 
            // txtdireccion
            // 
            this.txtdireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdireccion.Location = new System.Drawing.Point(9, 132);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(296, 20);
            this.txtdireccion.TabIndex = 2;
            // 
            // txtfecha
            // 
            this.txtfecha.BackColor = System.Drawing.SystemColors.Window;
            this.txtfecha.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfecha.ForeColor = System.Drawing.Color.Black;
            this.txtfecha.Location = new System.Drawing.Point(9, 83);
            this.txtfecha.Name = "txtfecha";
            this.txtfecha.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtfecha.Size = new System.Drawing.Size(296, 20);
            this.txtfecha.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "NOMBRE COMPLETO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "FECHA DE NACIMIENTO";
            // 
            // txtnombre
            // 
            this.txtnombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtnombre.Location = new System.Drawing.Point(9, 32);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(296, 20);
            this.txtnombre.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "DIRECCIÓN";
            // 
            // grpboxHorarios
            // 
            this.grpboxHorarios.Controls.Add(this.btnHorario);
            this.grpboxHorarios.Controls.Add(this.lblHorario);
            this.grpboxHorarios.Controls.Add(this.rdbmatutino);
            this.grpboxHorarios.Controls.Add(this.rdbvespertino);
            this.grpboxHorarios.Location = new System.Drawing.Point(352, 24);
            this.grpboxHorarios.Name = "grpboxHorarios";
            this.grpboxHorarios.Size = new System.Drawing.Size(135, 171);
            this.grpboxHorarios.TabIndex = 1;
            this.grpboxHorarios.TabStop = false;
            this.grpboxHorarios.Text = "HORARIOS";
            // 
            // btnHorario
            // 
            this.btnHorario.Location = new System.Drawing.Point(5, 124);
            this.btnHorario.Name = "btnHorario";
            this.btnHorario.Size = new System.Drawing.Size(129, 34);
            this.btnHorario.TabIndex = 3;
            this.btnHorario.Text = "SELECCIONAR HORARIO";
            this.btnHorario.UseVisualStyleBackColor = true;
            this.btnHorario.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblHorario
            // 
            this.lblHorario.AutoSize = true;
            this.lblHorario.Location = new System.Drawing.Point(43, 100);
            this.lblHorario.Name = "lblHorario";
            this.lblHorario.Size = new System.Drawing.Size(57, 13);
            this.lblHorario.TabIndex = 5;
            this.lblHorario.Text = "HORARIO";
            // 
            // rdbmatutino
            // 
            this.rdbmatutino.AutoSize = true;
            this.rdbmatutino.Location = new System.Drawing.Point(6, 67);
            this.rdbmatutino.Name = "rdbmatutino";
            this.rdbmatutino.Size = new System.Drawing.Size(82, 17);
            this.rdbmatutino.TabIndex = 1;
            this.rdbmatutino.Text = "MATUTINO";
            this.rdbmatutino.UseVisualStyleBackColor = true;
            // 
            // rdbvespertino
            // 
            this.rdbvespertino.AutoSize = true;
            this.rdbvespertino.Checked = true;
            this.rdbvespertino.Location = new System.Drawing.Point(6, 32);
            this.rdbvespertino.Name = "rdbvespertino";
            this.rdbvespertino.Size = new System.Drawing.Size(94, 17);
            this.rdbvespertino.TabIndex = 0;
            this.rdbvespertino.TabStop = true;
            this.rdbvespertino.Text = "VESPERTINO";
            this.rdbvespertino.UseVisualStyleBackColor = true;
            // 
            // btnagregar
            // 
            this.btnagregar.Location = new System.Drawing.Point(358, 224);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(129, 34);
            this.btnagregar.TabIndex = 2;
            this.btnagregar.Text = "AGREGAR";
            this.btnagregar.UseVisualStyleBackColor = true;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 285);
            this.Controls.Add(this.btnagregar);
            this.Controls.Add(this.grpboxHorarios);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "EXPEDIENTE ALUMNO";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpboxHorarios.ResumeLayout(false);
            this.grpboxHorarios.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.TextBox txtfecha;
        private System.Windows.Forms.GroupBox grpboxHorarios;
        private System.Windows.Forms.RadioButton rdbmatutino;
        private System.Windows.Forms.RadioButton rdbvespertino;
        private System.Windows.Forms.Button btnagregar;
        private System.Windows.Forms.ComboBox cmboxEdos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblHorario;
        private System.Windows.Forms.Button btnHorario;
    }
}

